import java.util.Scanner;

public class Ejercicio4 {
    public static void main(String[] args) {
        ejercicio4();
    }
    public static void ejercicio4(){
        Scanner scanner =new Scanner(System.in);
         /*Crea una aplicación que permita al usuario introducir un numero en base
        decimal. Una bez introducido, en el caso de que sea negativo, saltará un
        aviso de que nose puede hacer la operación. En el caso de que el numero
        sea positivo, saltará un menú para poder elegir el tipo de cambio de base
        a. Base 2
        b. Base 8
        c. Base 16.
        Cuando el usuario selecciona la base, se mostrará el resultado y volverá a
        salir el menu*/
            int decimal;
            int base;
            int base8=8;
            int base16=16;
            do {
                System.out.println("Por favor introduce un numero en base decimal");
                decimal=scanner.nextInt();
                if (decimal <= -1) {
                    System.out.println("No se puede operar");
                }else {
                System.out.println("1. Base 2" +
                                    "2. Base 8" +
                                    "3. Base 16");
                int opcion=scanner.nextInt();
                base=2;

                int division=decimal/base;
                division/=base;
                System.out.println(division);
                int resto=decimal%base;
                String base2=" ";
                System.out.println(resto);

                switch (opcion){
                    case 1:

                        break;
                }
            }
        }while (decimal > 1);
    }
}
