import java.util.Collection;
import java.util.Scanner;

public class Ejercicio3 {
    public static void main(String[] args) {
        ejercicio3();
    }
    public static void ejercicio3(){
        Scanner scanner= new Scanner(System.in);
        /*Realiza un programa que permita abrir una caja fuerte. Para ello, crea una
            variable donde guardas la clave de apertura (número de 4 dígitos). A
            continuación, el sistema empieza a pedir números al usuario para que
            pueda abrir la caja. El usuario contará con 4 intentos. El programa podrá
            ejecutar los siguientes casos:
            a. Si el usuario falla en su intento y todavía no ha agotado intentos
            aparecerá el mensaje “Intento fallido, prueba de nuevo”
            b. b. Si el usuario falla en su intento apareceré le mensaje de “Lo siento,
            caja bloqueada”
            c. c. Si el usuario adivina la combinación en 4 intentos o menos
            aparecerá el mensaje “Perfecto, la caja ha sido abierta”*/
            final int CLAVE=4444;
            int intentos=0;
            do {
                System.out.println("Introduce la Clave para abrir la caja");
                int numeroUsuario=scanner.nextInt();
                intentos++;
                if (numeroUsuario == CLAVE) {
                    System.out.println("Perfecto, has abierto la caja fuerte");
                    break;
                }
                    else{
                    System.out.println("Intento fallido, prueba de nuevo\n ");
                }
                if (intentos == 4) {
                    System.out.println("Lo siento has bloqueado la caja");
                }
            }while (intentos<4);
    }
}
