import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        ejercicio2();
    }
    public static void ejercicio2(){
        Scanner scanner=new Scanner(System.in);
        int aleatorio;
        Integer max =Integer.MAX_VALUE;
        int min =Integer.MAX_VALUE;
        int sumatorio=0;
        /*Crea una aplicación que pronostique los números de la bonoloto.
        Lo primero que pasará es que se le pide al usuario un número. */
        System.out.println("Introduce un numero");
        int numero=scanner.nextInt();
        /*A continuación, el sistema generará de forma automática 10 números entre 1 y 100.*/
        for (int i = 0; i <10 ; i++) {
            aleatorio=(int)(Math.random()*100)+1;
            aleatorio=Integer.MAX_VALUE;
            if (sumatorio > aleatorio) {
                System.out.println("Tu numero maximo es "+sumatorio );
            }
        }

        /*Una vez generados, se mostrará:
        a. El número más grande generado
        b. El número más pequeño generado
        c. El número medio generado
        d. La suma de todos los números
        e. Si el numero introducido por el usuario es alguno de los generados*/
    }
}
