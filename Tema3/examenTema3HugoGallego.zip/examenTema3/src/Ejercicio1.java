import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        ejercicio1();
    }
    static Scanner scanner = new Scanner(System.in);
    public static void ejercicio1(){
        int opcion=0;

        do {
            System.out.println("Introduce tu primer numero");
            int num1=scanner.nextInt();
            System.out.println("Introduce tu segundo numero");
            int num2=scanner.nextInt();
            while (num1<0 || num2<0){
                System.out.println("No se pueden realizar operaciones sobre números negativos");
                System.out.println("Vuelve a introducir su primer numero");
                num1=scanner.nextInt();
                System.out.println("Vuelve a introducir su segundo numero");
                num2=scanner.nextInt();
            }
                System.out.println("1. Suma\n" +
                                    "2. Resta\n" +
                                    "3. Multiplicación\n" +
                                    "4. División\n" +
                                    "5. Salir\n");
                opcion = scanner.nextInt();
                switch (opcion){
                    case 1:
                        System.out.println("El resultado de la opcion suma es "+(num1+num2));
                        break;
                    case 2:
                        System.out.println("El resultado de la opcion restas es "+(num1-num2));
                        break;
                    case 3:
                        System.out.println("El resultado de la opcion multiplicar es "+(num1*num2));
                        break;
                    case 4:
                        System.out.println("El resultado de la opcion division es "+((double)num1/num2));
                        break;
                     case 5:
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("No estas entre los rangos, intentalo de nuevo con otros numeros");
                        break;
                }
        }while (opcion != 5);
    }
}
