import java.util.Scanner;

public class Ejericicio4 {
    public static void main(String[] args) {
        /*
        4. Realizar una aplicación que gestione usuarios mediante array multidimensional
        donde se podrán guardar 10 elementos, donde los cuales constan de nombre
        (string), apellido (string), teléfono (int) y dni (string): La funcionalidad de la
        aplicación se guiará por un menú con las siguientes opciones:
        - Agregar persona: Pedirá los daos de nombre, apellido, teléfono y dni. Una vez
        pedidos agregará la persona en la lista. En el caso de no poder agregar más por
        estar la lista llena saltará un aviso.
        - Buscar persona: Pedirá un dni y sacará por pantalla todos los datos de la
        persona asociada con el formato Nombre: XXX, Apellido: XXX, Teléfono: XXX
        - Listar personas: Listará todos los elementos existentes en la lista con el
        formatoNombre: XXX, Apellido: XXX, Teléfono: XXX
        */
        Scanner scanner = new Scanner(System.in);
        Object[][] lista = new Object[10][2];

        String Nombre, Apellido, DNI;

        int opcion, telefono;

        int personasAgregadas = 0;
        do {
            System.out.println("1. Agregar persona");
            System.out.println("2. Buscar persona");
            System.out.println("3. Listar persona");
            System.out.println("4. Salir");
            System.out.println("¿Que quieres hacer?");
            opcion = scanner.nextInt();
            switch (opcion) {
                case 1:
                    if (personasAgregadas < 10) {
                        System.out.println("Introduce tu nombre:");
                        Nombre = scanner.next();
                        System.out.println("Introduce tu apellido:");
                        Apellido = scanner.next();
                        System.out.println("Introduce tu numero de telefono:");
                        telefono = scanner.nextInt();
                        System.out.println("Introduce tu dni:");
                        DNI = scanner.next();

                        lista[personasAgregadas][0] = Nombre;
                        lista[personasAgregadas][1] = Apellido;
                        lista[personasAgregadas][2] = telefono;
                        lista[personasAgregadas][3] = DNI;

                        personasAgregadas++;
                        System.out.println("Persona agregada correctamente.");
                    } else {
                        System.out.println("No se pueden agregar más personas, la lista está llena.");
                    }
                    break;

                case 2: // Buscar persona
                    System.out.print("Ingrese el DNI de la persona a buscar: ");
                    String dniBuscado = scanner.next();
                    for (int i = 0; i < lista.length; i++) {
                        if (DNI.equalsIgnoreCase(dniBuscado)) {
                            System.out.println(lista);
                        }
                    }
                    break;

                case 3: // Listar personas
                    if (personasAgregadas == 0) {
                        System.out.println("No hay personas registradas.");
                    } else {
                        // Mostrar todos los datos de las personas registradas
                        for (int i = 0; i < lista.length; i++) {
                            System.out.println("Nombre: " + lista[i][0] + ", Apellido: " + lista[i][1] + ", Teléfono: " + lista[i][2]);
                        }
                    }
                    break;

                case 4: // Salir
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida");
                    break;
            }
        }while (opcion != 4);
    }
}