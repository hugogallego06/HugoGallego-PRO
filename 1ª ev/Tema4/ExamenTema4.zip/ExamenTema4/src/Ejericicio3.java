import java.util.Arrays;
import java.util.Scanner;

public class Ejericicio3 {
    public static void main(String[] args) {
        /*
        3. Desarrollar un programa que tenga las siguientes funcionalidades sobre un
            array de 20 números, mediante un menú ofrezca las siguientes posibilidades
            a. Registrar posiciones; pedirá por teclado una a una las posiciones del
            array.
            b. Obtener elementos de una posición pedirá por teclado una posición y
            mostrará el dato asociado a dicha posición.
            c. Mostrar el array completo; listará el array completo, elemento a
            elemento
            d. Mostrar el array ordenado (con el algoritmo de la burbuja; lista el
            array completo ordenado de menor a mayor
            e. Rotar el array mueve todas las posiciones del array en una dirección (la
            que tu elijas) y lo muestra
        */
        Scanner scanner =new Scanner(System.in);
        int [] numeros= new int [20];
        int opcion;
        do {
            System.out.println("1. Registrar posiciones");
            System.out.println("2. Obtener elementos");
            System.out.println("3. Mostrar Array completo");
            System.out.println("4. Mostrar Array ordenado");
            System.out.println("5. Rotar Array");
            System.out.println("6. Salir");
            System.out.println("¿Que quieres hacer?");
            opcion=scanner.nextInt();
            switch (opcion){
                case 1:

                    for (int i = 0; i <numeros.length ; i++) {
                    System.out.println("Introduce los numeros que quieres que tenga tu array");
                    numeros[i]= scanner.nextInt();
                    }
                    break;
                case 2:
                    System.out.println("Introduce el numero de la posicion del array que desea ver");
                    int posicionUsuario=scanner.nextInt();
                    System.out.println(numeros[posicionUsuario]);
                    break;
                case 3:
                    for (int item : numeros) {
                        System.out.println(item);
                    }
                    break;
                case 4:
                    Arrays.sort(numeros);
                    for (int elements : numeros) {
                        System.out.println(elements);
                    }
                    break;
                case 5:
                    System.out.println("Rotacion derecha:");
                    int temporal=numeros[numeros.length-1];
                    for (int i = numeros.length-1; i >0 ; i--) {
                        numeros[i]=numeros[i-1];
                    }
                        numeros[0]=temporal;
                    for (int rotados : numeros) {
                        System.out.println("Los numeros rotados son "+rotados);
                    }
                case 6:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("No estas en el rango, intentalo de nuevo.");
                    break;

            }

        }while (opcion!=6);
    }
}
