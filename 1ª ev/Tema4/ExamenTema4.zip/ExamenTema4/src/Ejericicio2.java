import java.util.Scanner;

public class Ejericicio2 {
    public static void main(String[] args) {
        /*
        2. Desarrolla un programa que tenga las siguientes funcionalidades
        - Pedir al usuario la cantidad de datos que se quieren guardar
        - Rellene automáticamente la lista con números aleatorios entre 0 y 20
        - Una vez relleno se deberán de hacer automáticamente las siguientes acciones
        - System.out.println("** mostrar extremos"); Mostrará el elemento más grande
        y el elemento más pequeño
        - System.out.println("** mostrar par/impar"); Mostrará cuantos elementos son
        pares y cuantos impares
        - System.out.println("** mostrar repeticiones"); Pedirá un número por teclado y
        mostrará el número de veces que aparece en la lista
        */
        Scanner scanner=new Scanner(System.in);
        System.out.println("Introduce la cantidad de datos que desea guardar");
        int cantidad=scanner.nextInt();
        int [] numeros=new int [cantidad];
        for (int i = 0; i <numeros.length ; i++) {
            numeros[i]=(int)(Math.random()*21);
        }
        int min=-1;
        int max=21;
        for (int i = 0; i <numeros.length ; i++) {
            if (numeros[i] >min) {
                min=numeros[i];
            }
            if (numeros[i] < max) {
                max=numeros[i];
            }
        }
        System.out.println("El numero mas pequeño es "+min+" y el mas grande "+max);
        for (int i = 0; i <numeros.length ; i++) {
            if (numeros[i]%2 == 0) {
                System.out.println("Pares. "+numeros[i]);
            }else {
                System.out.println("Impares. " + numeros[i]);
            }
        }
        System.out.println("Introduce un numero para ver si pertenece a la lista");
        int numeroUsuario=scanner.nextInt();
        int incremento=0;
        for (int i = 0; i <numeros.length ; i++) {
            if (numeros[i] == numeroUsuario) {
                incremento++;
            }
        }
        System.out.println("Este numero aparece "+incremento+" veces en la lista");
    }
}
