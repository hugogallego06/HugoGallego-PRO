import java.util.Arrays;

public class Ejercicio1 {
    public static void main(String[] args) {
    /*
    1. Crear una aplicación que sea capaz de rellenar un array de 15 elementos sin que se
    repita ninguno de ellos. Para ello, los números que se meterán son aleatorios entre 0 y
    16. Una vez hecho esto:
    - Muestra los elementos del array sin ordenar.
    - Muestra los elementos del array ordenados.
    - Muestra solo los elementos que están en posiciones pares
    - Muestra solo los elementos que son pares
    */
    int []numeros=new int [15];
        for (int i = 0; i < numeros.length ; i++) {
            numeros[i]=(int)(Math.random()*17);
        }
        for (int sinOrdenar:numeros){
            System.out.println("Numeros sin ordenar "+sinOrdenar);
        }
        Arrays.sort(numeros);
        for (int ordenados:numeros) {
            System.out.println("Numeros ordenados " + ordenados);
        }
        for (int i = 0; i < numeros.length ; i++) {
            if (numeros[i]%2 == 0) {
                System.out.println("Elementos en posiciones pares: "+numeros[i]);
            }
        }
        for (int item:numeros){
            if (item %2 ==0) {
                System.out.println("Elementos pares"+item);
            }
            else {
                System.out.println("No hay elementos pares");
            }
        }
    }


}
